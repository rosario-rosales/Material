A Pen created at CodePen.io. You can find this one at http://codepen.io/chirox/pen/YwqKJM.

 This was all taken from http://tympanus.net/Development/ButtonStylesInspiration/ but I needed to see it in CodePen

Thanks Tympanus.net

Forked from [Dan Sullivan](http://codepen.io/dansully/)'s Pen [Button Styles Inspiration](http://codepen.io/dansully/pen/meVLaW/).