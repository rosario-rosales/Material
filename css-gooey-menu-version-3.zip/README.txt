A Pen created at CodePen.io. You can find this one at http://codepen.io/lbebber/pen/pvwZJp.

 Gooey menu with CSS and SVG filters. Version 3