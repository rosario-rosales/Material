ddHeroSlider
=========

**A lean responsive Flexbox slider with smooth transitions and text pagination created by [David Davis].**

  - Built with Flexbox
  - Responsive slider
  - lightweight jQuery



Version
----

1.0

Tech
-----------

Open source projects used:

* [Compass] - duh
* [Modernizr] - duh
* [jQuery] - duh 

Demo
-----------
[ddHeroSlider]

[ddHeroSlider]:http://david-james-davis.com/chproject
[jQuery]:http://jquery.com
[David Davis]:http://david-james-davis.com
[Modernizr]:http://modernizr.com/
[Compass]:http://compass-style.org/

