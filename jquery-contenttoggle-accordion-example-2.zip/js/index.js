$('.js-contentToggle').contentToggle({
  independent: true,
  toggleOptions : {
    duration: 400
  }
});