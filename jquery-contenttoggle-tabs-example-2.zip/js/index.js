$('.js-contentToggle').contentToggle({
  contentSelectorContext: false,
  triggerSelectorContext: false,
  noSelfClosing: true
});