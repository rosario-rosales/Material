//PURE CSS ACCORDION SLIDER

/* BROWSER COMPATILITY
--INTERNET EXPLORER 9+ (Loses Transitions + Looks Awful in IE8)
--GOOGLE CHROME
--MOZILLA FIREFOX
--OPERA [NOT TESTED - SHOULD WORK]
--SAFARI
*/
alsolike(
  "ujBcf", "learning",
  "zsonr", "USF Student Incubator",
  "qFysE", "Import Tumblr Posts"
);