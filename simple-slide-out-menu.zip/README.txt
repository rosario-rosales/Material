A Pen created at CodePen.io. You can find this one at http://codepen.io/noelietrex/pen/OPBKWj.

 This is a simple hamburger menu from font-awesome. When clicked, the menu slides out from the left. It relies on css for transition.