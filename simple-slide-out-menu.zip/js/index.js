$('.js-nav').click(function(){
  	$(this).parent().find('.menu').toggleClass('active');
});